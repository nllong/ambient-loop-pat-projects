

###### (Automatically generated documentation)

# Set Heat Pump Cooling Coil Rated COP

## Description
Set heat pump cooling coil gross rated COP.

## Modeler Description
Set heat pump cooling coil gross rated COP.

## Measure Type
ModelMeasure

## Taxonomy


## Arguments


### Cooling Coil Rated COP
Set the heat pump's cooling coil rated COP to this value.
**Name:** cool_cop,
**Type:** Double,
**Units:** ,
**Required:** true,
**Model Dependent:** false




