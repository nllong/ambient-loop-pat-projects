

###### (Automatically generated documentation)

# Set Exterior Wall Insulation R Value

## Description


## Modeler Description


## Measure Type
ModelMeasure

## Taxonomy


## Arguments


### Exterior Wall Insulation R-value (ft^2*h*R/Btu)

**Name:** wall_r,
**Type:** Double,
**Units:** ,
**Required:** true,
**Model Dependent:** false




