

###### (Automatically generated documentation)

# Set R-value of Insulation for Roofs to a Specific Value

## Description


## Modeler Description


## Measure Type
ModelMeasure

## Taxonomy


## Arguments


### Insulation R-value (ft^2*h*R/Btu).

**Name:** r_value,
**Type:** Double,
**Units:** ,
**Required:** true,
**Model Dependent:** false




