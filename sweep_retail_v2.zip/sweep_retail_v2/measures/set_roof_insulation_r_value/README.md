

###### (Automatically generated documentation)

# Set Roof Insulation R Value

## Description


## Modeler Description


## Measure Type
ModelMeasure

## Taxonomy


## Arguments


### Roof Insulation R-value (ft^2*h*R/Btu)

**Name:** roof_r,
**Type:** Double,
**Units:** ,
**Required:** true,
**Model Dependent:** false




