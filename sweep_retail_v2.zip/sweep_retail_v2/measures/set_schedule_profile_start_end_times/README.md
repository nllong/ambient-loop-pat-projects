

###### (Automatically generated documentation)

# Set Schedule Profile Start End Times

## Description
Expand or contract schedule profile by specifying new start and end times. The schedule profile shape is preserved.

## Modeler Description
Expand or contract schedule profile by specifying new start and end times. The schedule profile shape is preserved.

## Measure Type
ModelMeasure

## Taxonomy


## Arguments


### Schedule to Expand or Contract

**Name:** schedule,
**Type:** Choice,
**Units:** ,
**Required:** true,
**Model Dependent:** false

### Schedule Start (hr)

**Name:** new_start,
**Type:** Integer,
**Units:** ,
**Required:** true,
**Model Dependent:** false

### Schedule End (hr)

**Name:** new_end,
**Type:** Integer,
**Units:** ,
**Required:** true,
**Model Dependent:** false




