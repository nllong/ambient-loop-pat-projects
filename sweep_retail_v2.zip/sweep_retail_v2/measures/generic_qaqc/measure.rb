require 'erb'
require 'json'
require 'openstudio-standards'
require "#{File.dirname(__FILE__)}/resources/os_lib_helper_methods"

#start the measure
class GenericQAQC < OpenStudio::Ruleset::ReportingUserScript

  # require all .rb files in resources folder
  Dir[File.dirname(__FILE__) + '/resources/*.rb'].each {|file| require file }

  # all QAQC checks should be in OsLib_QAQC module
  include OsLib_QAQC
  # OsLib_CreateResults is needed for utility EDA programs but not the generic QAQC measure
  #include OsLib_CreateResults

  #define the name that a user will see, this method may be deprecated as
  #the display name in PAT comes from the name field in measure.xml
  def name
    return "Generic QAQC"
  end

  # human readable description
  def description
    return "This measure extracts key simulation results and performs basic model QAQC checks. Each category of checks provides a description of the source of the check. In some cases the target standards and tollerances are adjustable."
  end

  # human readable description of modeling approach
  def modeler_description
    return "Reads the model and sql file to pull out the necessary information and run the model checks.  The check results show up as warning messages in the measure's output on the PAT run tab."
  end

  def possible_check_categories
    results = []

    # gather options_check_weather_files (example data below not used since check_weather_files commented out for generic QAQC)
    options_check_weather_files = {}
    epw_ch_01 = {}
    epw_ch_01['climate_zone'] = '5B'
    options_check_weather_files['USA_CO_Golden-NREL.724666_TMY3.epw'] = epw_ch_01
    epw_ch_01['summer'] = []
    epw_ch_01['summer'] << 'Denver Centennial  Golden   N Ann Clg .4% Condns DB=>MWB'
    epw_ch_01['summer'] << 'Denver Centennial  Golden   N Ann Clg .4% Condns DP=>MDB'
    epw_ch_01['summer'] << 'Denver Centennial  Golden   N Ann Clg .4% Condns Enth=>MDB'
    epw_ch_01['summer'] << 'Denver Centennial  Golden   N Ann Clg .4% Condns WB=>MDB'
    epw_ch_01['winter'] = []
    epw_ch_01['winter'] << 'Denver Centennial  Golden   N Ann Htg 99.6% Condns DB'
    epw_ch_01['winter'] << 'Denver Centennial  Golden   N Ann Htg Wind 99.6% Condns WS=>MCDB'
    epw_ch_01['winter'] << 'Denver Centennial  Golden   N Ann Hum_n 99.6% Condns DP=>MCDB'
    # add additional weather with design day objects as required

    # gather inputs for check_mech_sys_capacity. Each option has a target value, min and max fractional tolerance, and units
    # in the future climate zone specific targets may be in standards
    options_check_mech_sys_capacity = {}
    options_check_mech_sys_capacity['chiller_max_flow_rate'] = {'target' => 2.4,'min' => 0.1, 'max' => 0.1,'units' => 'gal/ton*min'}
    options_check_mech_sys_capacity['air_loop_max_flow_rate'] = {'target' => 1.0,'min' => 0.1, 'max' => 0.1,'units' => 'cfm/ft^2'}
    options_check_mech_sys_capacity['air_loop_cooling_capacity'] = {'target' => 0.0033,'min' => 0.1, 'max' => 0.1,'units' => 'tons/ft^2'}
    options_check_mech_sys_capacity['zone_heating_capacity'] = {'target' => 12.5,'min' => 0.20, 'max' => 0.40,'units' => 'Btu/ft^2*h'}

    #results << {:method_name => 'check_weather_files',:cat => 'General',:standards => false,:data => options_check_weather_files,:min_tol => false,:max_tol => false, :units => nil}
    results << {:method_name => 'check_eui_reasonableness',:cat => 'General',:standards => true,:data => nil,:tol_min => 0.1,:tol_max => true,:units => 'fraction'}
    results << {:method_name => 'check_eui_by_end_use',:cat => 'General',:standards => true,:data => nil,:tol_min => 0.25,:tol_max => true,:units => 'fraction'}
    results << {:method_name => 'check_mech_sys_part_load_eff',:cat => 'General',:standards => true,:data => nil,:tol_min => 0.05,:tol_max => true,:units => 'fraction'}
    results << {:method_name => 'check_mech_sys_capacity',:cat => 'General',:standards => false,:data => options_check_mech_sys_capacity,:tol_min => false,:tol_max => false,:units => 'fraction'}
    results << {:method_name => 'check_simultaneous_heating_and_cooling',:cat => 'General',:standards => false,:data => nil,:tol_min => false,:tol_max => 0.05,:units => 'fraction'}
    results << {:method_name => 'check_internal_loads',:cat => 'Baseline',:standards => true,:data => nil,:tol_min => 0.1,:tol_max => true,:units => 'fraction'}
    results << {:method_name => 'check_schedules',:cat => 'Baseline',:standards => true,:data => nil,:tol_min => 0.05,:tol_max => true,:units => 'fraction'}
    results << {:method_name => 'check_envelope_conductance',:cat => 'Baseline',:standards => true,:data => nil,:tol_min => 0.1,:tol_max => true,:units => 'fraction'}
    results << {:method_name => 'check_domestic_hot_water',:cat => 'Baseline',:standards => true,:data => nil,:tol_min => 0.25,:tol_max => true,:units => 'fraction'}
    results << {:method_name => 'check_mech_sys_efficiency',:cat => 'Baseline',:standards => true,:data => nil,:tol_min => 0.1,:tol_max => true,:units => 'fraction'}
    results << {:method_name => 'check_mech_sys_type',:cat => 'Baseline',:standards => true,:data => nil,:tol_min => false,:tol_max => false,:units => nil}
    results << {:method_name => 'check_supply_air_and_thermostat_temp_difference',:cat => 'Baseline',:standards => false,:data => nil,:tol_min => 0.5,:tol_max => false,:units => 'F'}

    results
  end

  #define the arguments that the user will input
  def arguments()
    args = OpenStudio::Ruleset::OSArgumentVector.new

    # Make an argument for the template
    template_chs = OpenStudio::StringVector.new
    template_chs << 'DOE Ref Pre-1980'
    template_chs << 'DOE Ref 1980-2004'
    template_chs << '90.1-2004'
    template_chs << '90.1-2007'
    template_chs << '90.1-2010'
    template_chs << '90.1-2013'
    template = OpenStudio::Ruleset::OSArgument::makeChoiceArgument('template', template_chs, true)
    template.setDisplayName('Target ASHRAE Standard')
    template.setDescription('This used to set the target standard for most checks.')
    template.setDefaultValue('90.1-2013') # there is override variable in run method for this
    args << template

    # add arguments from possible_check_categories
    possible_check_categories.each do |hash|
      cat = hash[:cat]
      cat_input = "\'#{cat}\'"
      if hash[:standards]
        standards_input = ",\'selected ASHRAE standard\'"
      else
        standards_input = ''
      end
      if hash[:data].nil?
        data_input = ''
      else
        data_input = ",#{hash[:data]}"
      end
      if !hash[:tol_min]
        min = nil
        min_input = ''
      else
        min = hash[:tol_min]
        min_input = ",#{min}"
      end
      if hash[:tol_max].is_a? Float
        max = hash[:tol_max]
        max_input = ",#{max}"
      elsif !hash[:tol_max]
        max = nil
        max_input = ''
      else
        max = hash[:tol_min]
        max_input = ",#{max}"
      end

      name_cat_desc = eval("#{hash[:method_name]}(#{cat_input}#{data_input}#{standards_input}#{min_input}#{max_input},true)")
      arg = OpenStudio::Ruleset::OSArgument.makeBoolArgument(hash[:method_name], true)
      arg.setDisplayName("#{name_cat_desc[0]} (#{hash[:cat]})")
      arg.setDescription(name_cat_desc[2])
      arg.setDefaultValue(true)
      args << arg
      if !min.nil?
        arg_tol = OpenStudio::Ruleset::OSArgument.makeDoubleArgument("#{hash[:method_name]}_tol", true)
        arg_tol.setDisplayName("#{name_cat_desc[0]} Tolerance")
        arg_tol.setDefaultValue(min)
        arg_tol.setUnits(hash[:units])
        args << arg_tol
      end
      if hash[:tol_max].is_a? Float
        arg_max_tol = OpenStudio::Ruleset::OSArgument.makeDoubleArgument("#{hash[:method_name]}_max_tol", true)
        arg_max_tol.setDisplayName("#{name_cat_desc[0]} Max Tolerance")
        arg_max_tol.setDefaultValue(max)
        arg_max_tol.setUnits(hash[:units])
        args << arg_max_tol
      end

    end

    return args
  end #end the arguments method

  # return a vector of IdfObject's to request EnergyPlus objects needed by the run method
  def energyPlusOutputRequests(runner, user_arguments)
    super(runner, user_arguments)

    result = OpenStudio::IdfObjectVector.new

    # assign the user inputs to variables
    args = OsLib_HelperMethods.createRunVariables(runner, @model, user_arguments, arguments)
    unless args
      return false
    end

    # only add terminalvariables if that check is enabled
    if args['check_simultaneous_heating_and_cooling']
      # get the last model
      model = runner.lastOpenStudioModel
      if model.empty?
        runner.registerError("Cannot find last model.")
        return false
      end
      model = model.get

      # Request the terminal reheat coil and
      # terminal cooling rates for every VAV
      # reheat terminal.
      model.getAirTerminalSingleDuctVAVReheats.each do |term|

        # Reheat coil heating rate
        rht_coil = term.reheatCoil
        result << OpenStudio::IdfObject.load("Output:Variable,#{rht_coil.name},Heating Coil Heating Rate,Hourly;").get
        result << OpenStudio::IdfObject.load("Output:Variable,#{rht_coil.name},Heating Coil Air Heating Rate,Hourly;").get

        # Zone Air Terminal Sensible Heating Rate
        result << OpenStudio::IdfObject.load("Output:Variable,ADU #{term.name},Zone Air Terminal Sensible Cooling Rate,Hourly;").get

      end
    end

    return result
  end

  # define what happens when the measure is run
  def run(runner, user_arguments)
    super(runner, user_arguments)
    
    # make the runner a class variable
    @runner = runner

    # if true errors on QAQC sections will show full backtrace. Use for diagnostics
    @error_backtrace = false

    # register initial condition
    runner.registerInitialCondition("Starting QAQC report generation")

    # get sql, model, and web assets
    setup = OsLib_Reporting.setup(runner)
    unless setup
      return false
    end
    @model = setup[:model]
    # workspace = setup[:workspace]
    @sql = setup[:sqlFile]
    web_asset_path = setup[:web_asset_path]

    # assign the user inputs to variables
    args = OsLib_HelperMethods.createRunVariables(runner, @model, user_arguments, arguments)
    unless args
      return false
    end

    # vector to store the results and checks
    report_elems = OpenStudio::AttributeVector.new

    # used for edapt programs to populate xml file with extra data
    # report_elems << create_results

    # utility name to to used by some qaqc checks
    @utility_name = nil # for utility QAQC string is passed in
    default_target_standard = args['template'] # for utility QAQC this is hard coded, for generic it is user argument

    # for large scale analysis may want to infer this from building name so it will be in sync with template variables from earlier measures
    override_template_arg = false
    if override_template_arg
      template_chs = []
      template_chs << 'DOE Ref Pre-1980'
      template_chs << 'DOE Ref 1980-2004'
      template_chs << '90.1-2004'
      template_chs << '90.1-2007'
      template_chs << '90.1-2010'
      template_chs << '90.1-2013'
      # map standard
      template_chs.each do |template_ch|
        if @model.getBuilding.name.to_s.include?(template_ch)
          default_target_standard = template_ch
          if template_ch != args['template']
            runner.registerInfo("override_template_arg is true. Ignoring user argument of #{args['template']} and instead using #{template_ch}.")
          end
          break
        end
      end
    end

    # get building type, different standards path if multifamily
    building_type = ''
    if @model.getBuilding.standardsBuildingType.is_initialized
      building_type = @model.getBuilding.standardsBuildingType.get
    end

    # create an attribute vector to hold the checks
    check_elems = OpenStudio::AttributeVector.new

    # loop through QAQC categories where bool is true
    possible_check_categories.each do |hash|

      # skip if bool arg for this method is false
      next if args[hash[:method_name]] == false

      cat = hash[:cat]
      cat_input = "\'#{cat}\'"
      if hash[:standards]
        standards_input = ",\'#{default_target_standard}\'"
      else
        standards_input = ''
      end
      if hash[:data].nil?
        data_input = ''
      else
        data_input = ",#{hash[:data]}"
      end

      # get min tol
      if args.has_key?("#{hash[:method_name]}_tol")
        # get tol value
        tol = args["#{hash[:method_name]}_tol"]
        # set min inputs
        if tol.is_a? Float
          min_input = ",#{tol}"
        else
          min_input = ''
        end
      else
        min_input = ''
      end

      # get max tol
      if args.has_key?("#{hash[:method_name]}_max_tol")
        # get tol value
        max_tol = args["#{hash[:method_name]}_max_tol"]
        # set max inputs
        if max_tol.is_a? Float
          max_input = ",#{max_tol}"
        elsif hash[:tol_max] == true and hash[:tol_min].is_a? Float
          # if true then use double from min_tol
          max_input = ",#{args["#{hash[:method_name]}_tol"]}"
        else
          max_input = ''
        end
      else
        if hash[:tol_max] == true and hash[:tol_min].is_a? Float
          # if true then use double from min_tol
          max_input = ",#{args["#{hash[:method_name]}_tol"]}"
        else
          max_input = ''
        end
      end

      # run QAQC check
      eval("check_elems << #{hash[:method_name]}(#{cat_input}#{data_input}#{standards_input}#{min_input}#{max_input},false)")

    end

    # add checks to report_elems
    report_elems << OpenStudio::Attribute.new("checks", check_elems)

    # create an extra layer of report.  the first level gets thrown away.
    top_level_elems = OpenStudio::AttributeVector.new
    top_level_elems << OpenStudio::Attribute.new("report", report_elems)
    
    # create the report
    result = OpenStudio::Attribute.new("summary_report", top_level_elems)
    result.saveToXml(OpenStudio::Path.new("report.xml"))

    # closing the sql file
    @sql.close()

    # reporting final condition
    runner.registerFinalCondition("Finished generating report.xml.")

    # populate sections using attributes
    sections = OsLib_Reporting.sections_from_check_attributes(check_elems,runner)

    # generate html output
    OsLib_Reporting.gen_html("#{File.dirname(__FILE__)}report.html.erb",web_asset_path, sections, name)
    
    return true
 
  end #end the run method

end #end the measure

#this allows the measure to be use by the application
GenericQAQC.new.registerWithApplication