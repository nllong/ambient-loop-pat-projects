

###### (Automatically generated documentation)

# Shift Schedule Profile Time

## Description


## Modeler Description


## Measure Type
ModelMeasure

## Taxonomy


## Arguments


### Choose a Schedule to Shift the Time For.

**Name:** schedule,
**Type:** Choice,
**Units:** ,
**Required:** true,
**Model Dependent:** false

### Distribution for Random Shift Value Generator.

**Name:** dist,
**Type:** Choice,
**Units:** ,
**Required:** true,
**Model Dependent:** false

### Shift Schedule Profiles Forward Lower Limit (24hr, use decimal for sub hour).

**Name:** shift_ll,
**Type:** Double,
**Units:** ,
**Required:** true,
**Model Dependent:** false

### Shift Schedule Profiles Forward Upper Limit (24hr, use decimal for sub hour).

**Name:** shift_ul,
**Type:** Double,
**Units:** ,
**Required:** true,
**Model Dependent:** false

### Shift Schedule Profiles Peak for Triangular Distribution.

**Name:** shift_ct,
**Type:** Double,
**Units:** ,
**Required:** false,
**Model Dependent:** false




