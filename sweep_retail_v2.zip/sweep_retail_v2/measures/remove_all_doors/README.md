

###### (Automatically generated documentation)

# Remove All Doors

## Description
Removes all doors from building envelope.

## Modeler Description
Removes all doors from building envelope.

## Measure Type
ModelMeasure

## Taxonomy


## Arguments




This measure does not have any user arguments


