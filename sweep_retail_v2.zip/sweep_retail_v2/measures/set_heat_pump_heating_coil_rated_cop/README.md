

###### (Automatically generated documentation)

# Set Heat Pump Heating Coil Rated COP

## Description
Set heat pump heating coil gross rated COP.

## Modeler Description
Set heat pump heating coil gross rated COP.

## Measure Type
ModelMeasure

## Taxonomy


## Arguments


### Cooling Coil Rated COP
Set the heat pump's heating coil rated COP to this value.
**Name:** heat_cop,
**Type:** Double,
**Units:** ,
**Required:** true,
**Model Dependent:** false




